import Hero from "@/components/Hero";
import About from "@/components/About";
import Services from "@/components/Services";
import Vision from "@/components/Vision";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="scroll-smooth">
      <Hero />
      <About />
      <Services />
      <Vision />
      <Contact />
      <Footer />
    </div>
  );
};

export default Index;
