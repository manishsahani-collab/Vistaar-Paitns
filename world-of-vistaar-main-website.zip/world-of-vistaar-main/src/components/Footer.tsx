const Footer = () => {
  return (
    <footer className="py-8 bg-foreground text-background">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm opacity-80">
          © 2025 Vistaar Paints International. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;