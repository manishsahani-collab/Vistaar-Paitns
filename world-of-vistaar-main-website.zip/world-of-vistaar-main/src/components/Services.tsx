import { Globe, Palette, Gem, Handshake } from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Globe,
      title: "Global Exports",
      description: "Decorative & Industrial Paints worldwide"
    },
    {
      icon: Palette,
      title: "Custom Solutions",
      description: "Tailored coatings for architects & contractors"
    },
    {
      icon: Gem,
      title: "Premium Quality",
      description: "Eco-friendly, durable finishes, international standards"
    },
    {
      icon: Handshake,
      title: "Partnerships",
      description: "Long-term trust with businesses globally"
    }
  ];

  return (
    <section className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-foreground">
            What We Do
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive paint solutions for a global market
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-card p-8 rounded-xl card-elevated text-center group"
            >
              <div className="w-16 h-16 mx-auto mb-6 bg-primary/10 rounded-full flex items-center justify-center group-hover:bg-primary/20 transition-smooth">
                <service.icon className="h-8 w-8 text-primary" />
              </div>
              
              <h3 className="text-xl font-semibold mb-4 text-card-foreground">
                {service.title}
              </h3>
              
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;