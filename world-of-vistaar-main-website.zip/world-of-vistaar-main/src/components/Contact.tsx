import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Linkedin, Instagram, Facebook } from "lucide-react";

const Contact = () => {
  const contactInfo = [
    {
      icon: MapPin,
      label: "Location",
      value: "Rajkot, India"
    },
    {
      icon: Phone,
      label: "Phone",
      value: "+91 90338 51427"
    },
    {
      icon: Mail,
      label: "Email",
      value: "info@vistaarpaints.com"
    }
  ];

  const socialLinks = [
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Facebook, href: "#", label: "Facebook" }
  ];

  return (
    <section className="py-20 bg-contact-gradient text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Get In Touch
          </h2>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
            Ready to expand your business with premium paints? Let's connect.
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {contactInfo.map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <item.icon className="h-8 w-8" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{item.label}</h3>
                <p className="text-white/80">{item.value}</p>
              </div>
            ))}
          </div>
          
          <div className="text-center mb-8">
            <Button 
              variant="contact" 
              size="lg"
              onClick={() => window.open('mailto:info@vistaarpaints.com', '_blank')}
              className="text-lg px-8 py-4"
            >
              Partner With Us
            </Button>
          </div>
          
          <div className="flex justify-center space-x-6">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.href}
                aria-label={social.label}
                className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-white/20 transition-smooth"
              >
                <social.icon className="h-6 w-6" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;