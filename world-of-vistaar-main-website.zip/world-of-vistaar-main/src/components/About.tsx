const About = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-foreground">
            About Us
          </h2>
          
          <div className="prose prose-lg max-w-none">
            <p className="text-xl leading-relaxed text-muted-foreground mb-8">
              At <span className="text-primary font-semibold">Vistaar Paints International</span>, 
              we believe color has no boundaries.
            </p>
            
            <p className="text-lg leading-relaxed text-muted-foreground">
              With years of expertise in premium paints & coatings, we now bring our products 
              to the global market—offering quality, durability, and innovation trusted by 
              professionals and homeowners alike.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;